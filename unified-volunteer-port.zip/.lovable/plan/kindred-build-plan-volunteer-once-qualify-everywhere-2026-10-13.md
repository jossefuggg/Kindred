# Kindred build plan — "Volunteer once. Qualify everywhere."

The concept stays as approved. This plan covers the data, pages, server logic and build order.

## Stack adaptations (please confirm)
This project runs on TanStack Start (React + Vite + TS + Tailwind v4 + shadcn), not a plain Vite app. That means:
- **"Edge functions" become server functions.** A server function is server-side code the app calls directly. It gets the same rules: zod validation, JWT check, 64 KB cap, generic errors. Lovable AI is only called from them.
- **Design tokens live in `src/styles.css`** (Tailwind v4 has no `tailwind.config`). The locked token names stay (`--bg --surface --brand --accent --success-soft …`). Values use the brand HSL colours, converted to oklch.
- Fonts (Inter, Fraunces) are self-hosted through npm packages, so no CDN is used.

## Data model (Lovable Cloud), RLS in the same migration
| Table | Access model | Notes |
|---|---|---|
| profiles | public read (signed in), owner writes | headline, city, causes[], skills[], availability jsonb, avatar |
| user_roles + has_role() | own read, admin writes | app_role: admin, charity_admin, volunteer |
| organisations | public read, admin writes | 6 fictional orgs, cause, city |
| org_members | shared | charity_admin to org (one org each) |
| credential_types | public read | Safeguarding, Food Safety L1, First Aid, Manual Handling, Data Privacy |
| credential_acceptances | public read | which orgs accept which credential ("Accepted by…") |
| training_modules / lessons / quiz_questions | public read | answers are checked on the server only and never sent to the browser |
| user_credentials | public read, written by server only | issuer, issued_at, expires_at, verified |
| shifts | public read, org members write | date, duration, commitment, spots_total, spots_left, city, cause |
| shift_requirements | public read, org members write | shift to credential_type |
| bookings | shared (volunteer + org members) | unique(shift, user); status, attended, hours |
| endorsements | public read, org members write | text, org, volunteer |
| chat_messages | shared (booked + org coordinator) | Realtime; pinned flag; redacted text |
| progress | private | user, feature, key, step, total, draft, status |
| feature_flags | read all signed in, admin writes | kill switches per feature + AI |
| audit_log | admin read only, server writes | sign-up, role change, booking, attendance, credential, flag flips |
| ai_usage | admin read, server writes | user, feature, tokens, cost, fallback, reason (no prompts) |
| ai_budget | server only | one row per day, reserved/spent, cap $1 |
| rate_limits | server only | buckets: writes 120/min, AI 40/min + 800/day, sign-ups 5/IP/hour |
| seed_guard | private | makes the per-user first-visit seeding run only once |

Forbidden and unknown rows both return "not found". Booking uses an atomic RPC (`UPDATE shifts SET spots_left = spots_left-1 WHERE id=… AND spots_left>0`).

## Server functions
- `bookShift`: checks the user's credentials against the shift's requirements. If any are missing, it returns them with "Complete Food Safety L1 (12 min) to unlock N shifts". Otherwise it books atomically, adds the user to chat, posts the coordinator's welcome message and writes the audit log.
- `eligibilitySummary`: shows, for each missing credential, how many shifts and orgs it would unlock.
- `submitQuiz`: grades the quiz on the server. A pass issues the credential, writes the audit log and returns "Unlocked X shifts at Y charities".
- `saveProgress` / `resetProgress`: saves the user's place in trainings and the shift draft.
- `sendChatMessage`: redacts emails and phone numbers, applies the rate limit, then inserts the message.
- `markAttendance`: logs hours and an optional endorsement (org members only).
- `aiMatchShifts`: the "For you" top 3, each with a one-line reason. Uses the fast model. The fallback is a scored rule (availability + credentials + causes) with the same output shape.
- `aiDraftShift`: turns one sentence into a structured shift draft. Uses the strong model. The fallback is a keyword template.
- `seedForUser`: an idempotent first-visit seed. `resetDemoData` is admin only.
- `admin*`: flips flags, assigns roles, and reads usage and the audit log. Each one checks has_role on the server.

AI pattern for every AI feature: user text goes inside `<user_data>`, the answer is structured output validated again with zod, cost is reserved first with a conditional budget UPDATE (users can spend up to 80% of the cap, admins 100%), every call is logged to ai_usage, and the calm notice reads "AI is resting for today".

## Pages
- `/` landing page: the pitch plus one call to action
- `/auth`: email + Google, "Try as Maya / Alex / Food Bank"
- `/explore`: "For you", filters (cause, city, date, commitment), qualified vs "Needs" badges
- `/shift/$id`: shift details, map placeholder, live spots left, Book
- `/shift/$id/chat`: workspace layout, pinned logistics, Realtime
- `/learn`, `/learn/$moduleId`: lessons, quiz, fast demo mode, "Welcome back at step N"
- `/me`, `/v/$id`: profile, credential wallet, hours, orgs helped, endorsements, availability grid
- `/org`: KPIs (fill rate, volunteers this month, hours), post a shift with an AI draft, applicants and their wallets, attendance
- `/admin`: kill switches, AI spend vs cap, users and roles, audit log

Signed-in pages are protected. The org and admin pages also check roles on the server. On mobile, the nav becomes a bottom bar. Light and dark modes are both included.

## Seed data
- **Shared for everyone:** 6 orgs, 30 shifts over the next 14 days (about 14 need Food Safety L1), 5 modules with 3–5 lessons and 5 quiz questions each, and which orgs accept each credential.
- **Demo users:**
  - maya@demo (1 credential)
  - alex@demo (4 credentials, with past hours and endorsements)
  - foodbank@demo (charity_admin of City Food Bank)
- **First signup:** the first person to sign up becomes admin.
- **Per user on first visit:** sample bookings, messages and progress.

## Build order (each step leaves the app working)
1. Foundation: Cloud, auth, profiles, roles, flags, audit, AI tables, design tokens, shared layout pieces (AppShell, page templates, Section, StatTile, Card, Empty, Skeleton), theme toggle, protected pages, first user becomes admin, demo logins.
2. Marketplace: orgs, shifts and requirements seeded, /explore, /shift/$id.
3. Trainings, credentials and unlock: /learn, quiz, wallet issue.
4. Booking and eligibility engine (the "aha" moment).
5. Shift group chat (Realtime).
6. Profile /me and /v/$id.
7. Charity dashboard /org.
8. AI matchmaker and AI shift drafting.
9. Admin console, then demo-proofing, security pass, polish and README.

Cut list if behind, in order: AI drafting, endorsements, availability grid, map.
