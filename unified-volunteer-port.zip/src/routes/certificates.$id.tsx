import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import { z } from "zod";
import { Printer, Sprout } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Database } from "@/integrations/supabase/types";

const getCertificate = createServerFn({ method: "GET" })
  .inputValidator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
    const db = createClient<Database>(process.env["SUPABASE_URL"]!, key, {
      auth: { persistSession: false },
      global: {
        fetch: (input, init) => {
          const h = new Headers(init?.headers);
          if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) h.delete("Authorization");
          h.set("apikey", key);
          return fetch(input, { ...init, headers: h });
        },
      },
    });
    const { data: c } = await db
      .from("certificates")
      .select("id, code, holder_name, course_title, issuer_name, issued_at, expires_at")
      .eq("id", data.id)
      .maybeSingle();
    return c;
  });

export const Route = createFileRoute("/certificates/$id")({
  loader: async ({ params }) => {
    const ok = z.string().uuid().safeParse(params.id);
    if (!ok.success) throw notFound();
    const c = await getCertificate({ data: { id: params.id } });
    if (!c) throw notFound();
    return c;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.course_title} certificate · Kindred` : "Certificate · Kindred" },
      { name: "description", content: loaderData ? `Verified Kindred certificate for ${loaderData.holder_name}.` : "Verified Kindred certificate." },
      { property: "og:title", content: loaderData ? `${loaderData.holder_name} completed ${loaderData.course_title}` : "Kindred certificate" },
      { property: "og:description", content: "Verified on Kindred. Volunteer once. Qualify everywhere." },
    ],
  }),
  component: Certificate,
  notFoundComponent: () => (
    <div className="flex min-h-screen items-center justify-center bg-bg p-6 text-center">
      <div><p className="font-display text-2xl font-semibold text-text">Certificate not found</p><p className="mt-2 text-text-2">Check the link and try again.</p></div>
    </div>
  ),
});

function Certificate() {
  const c = Route.useLoaderData();
  const date = (d: string) => new Date(d).toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" });
  return (
    <div className="min-h-screen bg-surface-2 px-4 py-10 print:bg-surface print:p-0">
      <div className="mx-auto mb-6 flex max-w-3xl justify-between print:hidden">
        <Link to="/dashboard" className="text-sm font-semibold text-brand hover:underline">Back to Kindred</Link>
        <Button variant="secondary" onClick={() => window.print()}><Printer /> Print</Button>
      </div>
      <div className="mx-auto max-w-3xl rounded-xl border-8 border-double border-forest bg-bg p-8 text-center shadow-lg sm:p-14 print:shadow-none">
        <p className="text-xs font-semibold uppercase tracking-widest text-forest">Certificate of completion</p>
        <h1 className="mt-6 font-display text-4xl font-bold tracking-tight text-text">{c.course_title}</h1>
        <p className="mt-8 text-text-2">This certifies that</p>
        <p className="mt-2 font-display text-3xl font-semibold text-brand">{c.holder_name}</p>
        <p className="mt-4 text-text-2">completed every lesson of this course, issued by</p>
        <p className="mt-1 font-semibold text-text">{c.issuer_name}</p>
        <div className="mt-10 flex flex-col items-center justify-between gap-6 sm:flex-row">
          <div className="text-left text-sm text-text-2">
            <p>Issued {date(c.issued_at)}</p>
            <p>Valid until {date(c.expires_at)}</p>
          </div>
          <div className="flex size-24 items-center justify-center rounded-full bg-gradient-brand text-on-brand shadow-md ring-4 ring-brand-soft">
            <Sprout className="size-10" />
          </div>
          <div className="text-right text-sm text-text-2">
            <p>Verification ID</p>
            <p className="font-mono font-semibold tracking-wider text-text">{c.code}</p>
          </div>
        </div>
        <p className="mt-10 text-xs text-text-3">Accepted by every participating charity on Kindred.</p>
      </div>
    </div>
  );
}
