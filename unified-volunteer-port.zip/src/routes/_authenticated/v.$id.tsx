import { createFileRoute } from "@tanstack/react-router";
import { StandardPage } from "@/components/layout/page";
import { VolunteerProfile } from "@/components/volunteer-profile";

export const Route = createFileRoute("/_authenticated/v/$id")({
  head: () => ({ meta: [{ title: "Volunteer profile · Kindred" }, { name: "description", content: "A verified Kindred volunteer profile." }] }),
  component: PublicProfile,
});

function PublicProfile() {
  const { id } = Route.useParams();
  return (
    <StandardPage eyebrow="Volunteer" title="Volunteer profile" lead="Verified on Kindred.">
      <VolunteerProfile userId={id} editable={false} />
    </StandardPage>
  );
}
