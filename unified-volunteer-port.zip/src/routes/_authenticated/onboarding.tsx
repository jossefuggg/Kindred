import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { z } from "zod";
import { Building2, HandHeart, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { StandardPage, Section } from "@/components/layout/page";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/onboarding")({
  head: () => ({ meta: [{ title: "Welcome · Kindred" }, { name: "description", content: "Set up your Kindred account." }] }),
  component: Onboarding,
});

const Base = z.object({
  name: z.string().trim().min(1, "Add your name").max(80),
  area: z.string().trim().min(1, "Add your area").max(80),
  bio: z.string().trim().max(500),
});
const Charity = z.object({
  charityName: z.string().trim().min(2, "Add the charity name").max(120),
  cause: z.string().trim().max(60),
  description: z.string().trim().max(1000),
  website: z.string().trim().max(200),
});

function Onboarding() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [role, setRole] = useState<"volunteer" | "charity">("volunteer");
  const [f, setF] = useState({ name: "", area: "", bio: "", charityName: "", cause: "", description: "", website: "" });
  const [busy, setBusy] = useState(false);
  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const b = Base.safeParse(f);
    if (!b.success) {
      toast.error(b.error.issues[0]?.message ?? "Check your details");
      return;
    }
    const c = role === "charity" ? Charity.safeParse(f) : null;
    if (c && !c.success) {
      toast.error(c.error.issues[0]?.message ?? "Check your details");
      return;
    }
    setBusy(true);
    const { error } = await supabase.rpc("complete_onboarding", {
      _role: role,
      _name: b.data.name,
      _area: b.data.area,
      _bio: b.data.bio,
      _charity_name: c?.data?.charityName ?? "",
      _cause: c?.data?.cause ?? "",
      _description: c?.data?.description ?? "",
      _website: c?.data?.website ?? "",
    });
    setBusy(false);
    if (error) {
      toast.error(error.message.includes("already") ? "You're already set up." : "We couldn't save that. Try again.");
      if (error.message.includes("already")) navigate({ to: "/dashboard" });
      return;
    }
    await qc.invalidateQueries();
    toast.success("You're all set");
    navigate({ to: role === "charity" ? "/dashboard" : "/explore" });
  }

  const choices = [
    { key: "volunteer" as const, icon: HandHeart, title: "I want to volunteer", body: "Find shifts and earn certificates." },
    { key: "charity" as const, icon: Building2, title: "I run a charity", body: "Post shifts and onboard volunteers." },
  ];

  return (
    <StandardPage eyebrow="Welcome" title="Let's set you up" lead="You pick this once. It takes a minute.">
      <form onSubmit={submit} className="flex flex-col gap-10">
        <div className="grid gap-4 sm:grid-cols-2">
          {choices.map((c) => (
            <button
              type="button"
              key={c.key}
              onClick={() => setRole(c.key)}
              className={cn(
                "flex items-start gap-4 rounded-xl border-2 bg-surface p-5 text-left transition-all duration-200",
                role === c.key ? "border-brand shadow-md" : "border-border hover:border-brand/40",
              )}
            >
              <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-brand-soft text-brand">
                <c.icon className="size-5" />
              </span>
              <span>
                <span className="block font-semibold text-text">{c.title}</span>
                <span className="text-sm text-text-2">{c.body}</span>
              </span>
            </button>
          ))}
        </div>

        <Section title="About you">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Your name"><Input value={f.name} onChange={set("name")} maxLength={80} /></Field>
            <Field label="Area"><Input value={f.area} onChange={set("area")} placeholder="e.g. City Centre" maxLength={80} /></Field>
            <div className="sm:col-span-2">
              <Field label="Short bio"><Textarea value={f.bio} onChange={set("bio")} maxLength={500} rows={3} /></Field>
            </div>
          </div>
        </Section>

        {role === "charity" && (
          <Section title="Your charity">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Charity name"><Input value={f.charityName} onChange={set("charityName")} maxLength={120} /></Field>
              <Field label="Cause"><Input value={f.cause} onChange={set("cause")} placeholder="e.g. Food" maxLength={60} /></Field>
              <Field label="Website"><Input value={f.website} onChange={set("website")} maxLength={200} /></Field>
              <div className="sm:col-span-2">
                <Field label="Description"><Textarea value={f.description} onChange={set("description")} maxLength={1000} rows={3} /></Field>
              </div>
            </div>
          </Section>
        )}

        <div>
          <Button type="submit" size="lg" disabled={busy}>
            {busy && <Loader2 className="animate-spin" />} Continue
          </Button>
        </div>
      </form>
    </StandardPage>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
