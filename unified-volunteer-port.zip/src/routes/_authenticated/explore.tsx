import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useMemo, useState } from "react";
import { CalendarHeart, GraduationCap, Sparkles } from "lucide-react";
import { StandardPage, Section } from "@/components/layout/page";
import { CardSkeletonGrid, Empty } from "@/components/layout/blocks";
import { ShiftCard } from "@/components/shift-card";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useEligibility } from "@/hooks/use-eligibility";
import { matchShifts } from "@/lib/ai.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/explore")({
  validateSearch: (s: Record<string, unknown>): { qualified?: number } => (s["qualified"] ? { qualified: 1 } : {}),
  head: () => ({
    meta: [
      { title: "Explore shifts · Kindred" },
      { name: "description", content: "Find volunteer shifts near you that you're already qualified for." },
      { property: "og:title", content: "Explore shifts · Kindred" },
      { property: "og:description", content: "Find volunteer shifts near you that you're already qualified for." },
    ],
  }),
  component: Explore,
});

const WHEN = [
  { key: "all", label: "Any time" },
  { key: "week", label: "This week" },
  { key: "weekend", label: "Weekend" },
] as const;

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "shrink-0 rounded-full border px-4 py-1.5 text-sm font-medium transition-colors duration-150",
        active ? "border-brand bg-brand text-on-brand" : "border-border bg-surface text-text-2 hover:border-brand/50",
      )}
    >
      {children}
    </button>
  );
}

function Explore() {
  const { user } = useAuth();
  const el = useEligibility();
  const match = useServerFn(matchShifts);
  const quick = useQuery({
    queryKey: ["for-you-quick", user?.id, el.certs.length],
    enabled: !!user,
    staleTime: 5 * 60_000,
    queryFn: () => match({ data: { quick: true } }),
  });
  const ai = useQuery({
    queryKey: ["for-you", user?.id, el.certs.length],
    enabled: !!user,
    staleTime: 30 * 60_000,
    gcTime: 60 * 60_000,
    queryFn: () => match({ data: {} }),
  });
  const forYou = ai.data ? ai : quick;
  const aiPending = !ai.data && ai.isFetching;

  const [cause, setCause] = useState("All");
  const [city, setCity] = useState("All");
  const [commit, setCommit] = useState("All");
  const [when, setWhen] = useState<(typeof WHEN)[number]["key"]>("all");
  const search = Route.useSearch();
  const [onlyQualified, setOnlyQualified] = useState(!!search.qualified);

  const causes = useMemo(() => ["All", ...new Set(el.shifts.map((s) => s.cause))], [el.shifts]);
  const cities = useMemo(() => ["All", ...new Set(el.shifts.map((s) => s.city))], [el.shifts]);

  const list = el.shifts.filter((s) => {
    const d = new Date(s.starts_at);
    if (cause !== "All" && s.cause !== cause) return false;
    if (city !== "All" && s.city !== city) return false;
    if (commit !== "All" && s.commitment !== commit) return false;
    if (when === "week" && d.getTime() - Date.now() > 7 * 86400_000) return false;
    if (when === "weekend" && d.getDay() !== 0 && d.getDay() !== 6) return false;
    if (onlyQualified && el.missingTitles(s.id).length) return false;
    return true;
  });

  const name = (user?.user_metadata?.["display_name"] as string | undefined)?.split(" ")[0];
  const picks = (forYou.data?.data ?? [])
    .map((p) => ({ ...p, shift: el.shifts.find((s) => s.id === p.shift_id) }))
    .filter((p) => p.shift);

  return (
    <StandardPage eyebrow="Explore" title={name ? `Hi ${name}` : "Explore shifts"} lead="Shifts near you, bookable in one tap.">
      {el.best && (
        <Link
          to="/courses/$id"
          params={{ id: el.best.courseId }}
          className="flex flex-col gap-4 rounded-xl bg-gradient-forest p-5 text-on-brand shadow-md transition-transform duration-200 hover:-translate-y-0.5 sm:flex-row sm:items-center"
        >
          <span className="flex size-11 shrink-0 items-center justify-center rounded-full bg-surface/20">
            <GraduationCap className="size-5" />
          </span>
          <span className="flex-1">
            <span className="block font-display text-lg font-semibold">
              Complete {el.best.title} ({el.best.minutes} min) to unlock {el.best.shifts} shifts
            </span>
            <span className="text-sm opacity-90">Accepted by every charity on Kindred.</span>
          </span>
          <span className="rounded-full bg-surface px-4 py-2 text-sm font-semibold text-forest">Start now</span>
        </Link>
      )}

      <Section
        title="For you"
        action={
          aiPending ? (
            <span className="flex items-center gap-1 text-xs text-text-3"><Sparkles className="size-3.5 animate-pulse" /> Personalising…</span>
          ) : forYou.data?.fallback ? (
            <span className="text-xs text-text-3">{forYou.data.notice}</span>
          ) : forYou.data ? (
            <span className="flex items-center gap-1 text-xs text-forest"><Sparkles className="size-3.5" /> AI-matched</span>
          ) : null
        }
      >
        {!forYou.data || el.loading ? (
          <div className="flex gap-4 overflow-hidden"><CardSkeletonGrid count={3} /></div>
        ) : picks.length ? (
          <div className="-mx-4 flex gap-4 overflow-x-auto px-4 pb-2">
            {picks.map((p) => (
              <ShiftCard key={p.shift_id} shift={p.shift!} missing={el.missingTitles(p.shift_id)} reason={p.reason} compact />
            ))}
          </div>
        ) : (
          <p className="text-sm text-text-2">Add your availability on your profile for better matches.</p>
        )}
      </Section>

      <Section title={`All shifts · ${list.length}`}>
        <div className="flex flex-col gap-3">
          <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
            {causes.map((c) => <Chip key={c} active={cause === c} onClick={() => setCause(c)}>{c === "All" ? "All causes" : c}</Chip>)}
          </div>
          <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-1">
            {cities.map((c) => <Chip key={c} active={city === c} onClick={() => setCity(c)}>{c === "All" ? "Everywhere" : c}</Chip>)}
            <span className="mx-1 w-px shrink-0 bg-border" />
            {["All", "2 hrs", "one-off", "weekly"].map((c) => (
              <Chip key={c} active={commit === c} onClick={() => setCommit(c)}>{c === "All" ? "Any length" : c}</Chip>
            ))}
            <span className="mx-1 w-px shrink-0 bg-border" />
            {WHEN.map((w) => <Chip key={w.key} active={when === w.key} onClick={() => setWhen(w.key)}>{w.label}</Chip>)}
            <Chip active={onlyQualified} onClick={() => setOnlyQualified(!onlyQualified)}>Qualified only</Chip>
          </div>
        </div>
        {el.loading ? (
          <CardSkeletonGrid />
        ) : list.length === 0 ? (
          <Empty
            icon={CalendarHeart}
            title="No shifts match these filters"
            body="Try another area or date."
            action={<Button variant="secondary" onClick={() => { setCause("All"); setCity("All"); setCommit("All"); setWhen("all"); setOnlyQualified(false); }}>Clear filters</Button>}
          />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((s) => <ShiftCard key={s.id} shift={s} missing={el.missingTitles(s.id)} />)}
          </div>
        )}
      </Section>
    </StandardPage>
  );
}
