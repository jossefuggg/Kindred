import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { ArrowDown, ArrowUp, BookOpen, Plus, Save, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { DetailPage, Section } from "@/components/layout/page";
import { Empty } from "@/components/layout/blocks";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useAuth } from "@/hooks/use-auth";

export const Route = createFileRoute("/_authenticated/courses/$id/edit")({
  head: () => ({ meta: [{ title: "Edit course · Kindred" }, { name: "description", content: "Edit lessons in the shared library." }] }),
  component: Editor,
});

type Lesson = { id: string; title: string; content: string; position: number };

function Editor() {
  const { id } = Route.useParams();
  const { user, hasRole } = useAuth();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const course = useQuery({
    queryKey: ["course", id],
    queryFn: async () => {
      const { data } = await supabase.from("courses").select("*, charities!courses_charity_id_fkey(name), lessons(id, title, content, position)").eq("id", id).maybeSingle();
      if (data) data.lessons.sort((a, b) => a.position - b.position);
      return data;
    },
  });
  const [meta, setMeta] = useState({ title: "", summary: "", minutes: 10 });
  const [lessons, setLessons] = useState<Lesson[]>([]);

  useEffect(() => {
    if (course.data) {
      setMeta({ title: course.data.title, summary: course.data.summary, minutes: course.data.minutes });
      setLessons(course.data.lessons);
    }
  }, [course.data]);

  if (course.isLoading) return <div className="mx-auto max-w-3xl p-6"><Skeleton className="h-96 rounded-xl" /></div>;
  if (!course.data || !hasRole("charity_admin"))
    return <div className="mx-auto max-w-3xl p-6"><Empty icon={BookOpen} title="Course not found" body="Only charities can edit courses." action={<Button asChild><Link to="/courses">Library</Link></Button>} /></div>;

  const refresh = () => qc.invalidateQueries({ queryKey: ["course", id] });

  async function saveMeta() {
    if (meta.title.trim().length < 2) return void toast.error("Add a title");
    const { error } = await supabase.from("courses").update({ title: meta.title.trim().slice(0, 120), summary: meta.summary.slice(0, 300), minutes: Math.max(1, Math.min(240, meta.minutes)) }).eq("id", id);
    if (error) return void toast.error("Couldn't save.");
    toast.success("Saved");
    refresh();
    qc.invalidateQueries({ queryKey: ["courses"] });
  }
  async function saveLesson(l: Lesson) {
    const { error } = await supabase.from("lessons").update({ title: l.title.slice(0, 160) || "Untitled", content: l.content.slice(0, 20000) }).eq("id", l.id);
    if (error) return void toast.error("Couldn't save lesson.");
    toast.success("Lesson saved");
    refresh();
  }
  async function addLesson() {
    const { error } = await supabase.from("lessons").insert({ course_id: id, title: "New lesson", content: "", position: lessons.length + 1 });
    if (error) return void toast.error("Couldn't add a lesson.");
    refresh();
  }
  async function move(i: number, dir: -1 | 1) {
    const a = lessons[i], b = lessons[i + dir];
    if (!a || !b) return;
    await Promise.all([
      supabase.from("lessons").update({ position: b.position }).eq("id", a.id),
      supabase.from("lessons").update({ position: a.position }).eq("id", b.id),
    ]);
    refresh();
  }
  async function removeLesson(lid: string) {
    await supabase.from("lessons").delete().eq("id", lid);
    refresh();
  }
  async function deleteCourse() {
    const { error } = await supabase.from("courses").delete().eq("id", id);
    if (error) return void toast.error("Only the creator can delete this course.");
    qc.invalidateQueries({ queryKey: ["courses"] });
    navigate({ to: "/courses" });
  }

  const isCreator = course.data.created_by === user?.id;

  return (
    <DetailPage backTo="/courses" backLabel="Library" eyebrow="Course editor" title={course.data.title} lead="Shared library: any charity can improve it.">
      <Section title="Details">
        <div className="flex flex-col gap-4 rounded-xl border border-border bg-surface p-5">
          <div className="flex flex-col gap-2"><Label>Title</Label><Input value={meta.title} maxLength={120} onChange={(e) => setMeta({ ...meta, title: e.target.value })} /></div>
          <div className="flex flex-col gap-2"><Label>Summary</Label><Input value={meta.summary} maxLength={300} onChange={(e) => setMeta({ ...meta, summary: e.target.value })} /></div>
          <div className="flex flex-col gap-2"><Label>Minutes</Label><Input type="number" min={1} max={240} value={meta.minutes} onChange={(e) => setMeta({ ...meta, minutes: Number(e.target.value) })} /></div>
          <div><Button onClick={saveMeta}><Save /> Save details</Button></div>
        </div>
      </Section>

      <Section title="Lessons" action={<Button variant="soft" size="sm" onClick={addLesson}><Plus /> Add lesson</Button>}>
        {lessons.length === 0 ? (
          <Empty icon={BookOpen} title="No lessons yet" body="Add the first lesson to get started." action={<Button onClick={addLesson}><Plus /> Add lesson</Button>} />
        ) : (
          lessons.map((l, i) => (
            <div key={l.id} className="flex flex-col gap-3 rounded-xl border border-border bg-surface p-4">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold tabular-nums text-text-3">{i + 1}</span>
                <Input value={l.title} maxLength={160} onChange={(e) => setLessons(lessons.map((x) => (x.id === l.id ? { ...x, title: e.target.value } : x)))} />
                <Button variant="ghost" size="icon" onClick={() => move(i, -1)} disabled={i === 0} aria-label="Move up"><ArrowUp /></Button>
                <Button variant="ghost" size="icon" onClick={() => move(i, 1)} disabled={i === lessons.length - 1} aria-label="Move down"><ArrowDown /></Button>
                <Button variant="ghost" size="icon" onClick={() => removeLesson(l.id)} aria-label="Delete lesson"><Trash2 /></Button>
              </div>
              <Textarea rows={5} value={l.content} maxLength={20000} onChange={(e) => setLessons(lessons.map((x) => (x.id === l.id ? { ...x, content: e.target.value } : x)))} />
              <div><Button size="sm" variant="secondary" onClick={() => saveLesson(l)}>Save lesson</Button></div>
            </div>
          ))
        )}
      </Section>

      {isCreator && (
        <AlertDialog>
          <AlertDialogTrigger asChild><Button variant="danger" className="self-start"><Trash2 /> Delete course</Button></AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete this course?</AlertDialogTitle>
              <AlertDialogDescription>It disappears from every charity's library and program.</AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={deleteCourse}>Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </DetailPage>
  );
}
