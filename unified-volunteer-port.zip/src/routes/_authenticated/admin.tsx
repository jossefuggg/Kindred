import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Bot, RotateCcw, ShieldOff, Users } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { WidePage, Section } from "@/components/layout/page";
import { Empty, KpiRow, StatTile } from "@/components/layout/blocks";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/use-auth";
import { flagsQuery } from "@/lib/data";
import { adminSummary, resetDemoData } from "@/lib/demo.functions";
import { pct } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin · Kindred" }, { name: "description", content: "Platform controls." }] }),
  component: Admin,
});

const ROLES = ["admin", "charity_admin", "volunteer"] as const;

function Admin() {
  const { hasRole, ready, roles } = useAuth();
  const qc = useQueryClient();
  const summary = useServerFn(adminSummary);
  const reset = useServerFn(resetDemoData);
  const isAdmin = hasRole("admin");
  const [search, setSearch] = useState("");
  const [action, setAction] = useState("all");

  const flags = useQuery({ ...flagsQuery(), enabled: isAdmin });
  const sum = useQuery({ queryKey: ["admin-summary"], enabled: isAdmin, queryFn: () => summary() });
  const today = new Date().toISOString().slice(0, 10);
  const usage = useQuery({
    queryKey: ["ai-usage"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("ai_usage").select("*").gte("created_at", today).order("created_at", { ascending: false }).limit(200)).data ?? [],
  });
  const budget = useQuery({
    queryKey: ["ai-budget"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("ai_budget").select("*").eq("day", today).maybeSingle()).data,
  });
  const audit = useQuery({
    queryKey: ["audit"],
    enabled: isAdmin,
    queryFn: async () => (await supabase.from("audit_log").select("*").order("created_at", { ascending: false }).limit(50)).data ?? [],
  });

  if (!ready || (roles.length === 0)) return <div className="mx-auto max-w-5xl p-6"><Skeleton className="h-64 rounded-xl" /></div>;
  if (!isAdmin) return <div className="mx-auto max-w-3xl p-6"><Empty icon={ShieldOff} title="Page not found" body="This page doesn't exist." action={<Button asChild><Link to="/explore">Go home</Link></Button>} /></div>;

  async function flip(key: string, enabled: boolean) {
    const { error } = await supabase.from("feature_flags").update({ enabled }).eq("key", key);
    if (error) return void toast.error("Couldn't change that switch.");
    qc.invalidateQueries({ queryKey: ["flags"] });
    qc.invalidateQueries({ queryKey: ["audit"] });
  }
  async function setRole(user: string, role: (typeof ROLES)[number], grant: boolean) {
    const { error } = await supabase.rpc("admin_set_role", { _user: user, _role: role, _grant: grant });
    if (error) return void toast.error("Couldn't change that role.");
    qc.invalidateQueries({ queryKey: ["admin-summary"] });
    qc.invalidateQueries({ queryKey: ["audit"] });
  }

  const spent = Number(budget.data?.spent_usd ?? 0);
  const cap = Number(budget.data?.cap_usd ?? 1);
  const calls = usage.data?.length ?? 0;
  const fallbacks = (usage.data ?? []).filter((u) => u.fallback).length;
  const users = (sum.data?.users ?? []).filter((u) => u.display_name.toLowerCase().includes(search.toLowerCase()));
  const actions = ["all", ...new Set((audit.data ?? []).map((a) => a.action))];

  return (
    <WidePage
      eyebrow="Admin"
      title="Platform controls"
      lead="Switches, AI spend and activity."
      actions={<Button variant="secondary" onClick={async () => { const r = await reset(); await qc.invalidateQueries(); toast.success(`Reset ${r.reset} demo accounts`); }}><RotateCcw /> Reset demo data</Button>}
    >
      <KpiRow>
        <StatTile label="Users" value={String(sum.data?.userCount ?? "–")} icon={Users} />
        <StatTile label="AI spend today" value={`$${spent.toFixed(3)}`} hint={`of $${cap.toFixed(2)} cap`} icon={Bot} />
        <StatTile label="AI calls today" value={String(calls)} />
        <StatTile label="Fallback rate" value={pct(calls ? (fallbacks / calls) * 100 : 0)} />
      </KpiRow>

      <Tabs defaultValue="switches">
        <TabsList className="w-full justify-start overflow-x-auto">
          <TabsTrigger value="switches">Switches</TabsTrigger>
          <TabsTrigger value="ai">AI</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="audit">Audit log</TabsTrigger>
        </TabsList>

        <TabsContent value="switches" className="mt-6">
          <div className="grid gap-3 sm:grid-cols-2">
            {(flags.data ?? []).map((f) => (
              <label key={f.key} className="flex items-center justify-between rounded-xl border border-border bg-surface p-4">
                <span><span className="block font-semibold text-text">{f.label}</span><span className="text-xs text-text-3">{f.enabled ? "On" : "Switched off"}</span></span>
                <Switch checked={f.enabled} onCheckedChange={(v) => flip(f.key, v)} />
              </label>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ai" className="mt-6 flex flex-col gap-6">
          <div className="rounded-xl border border-border bg-surface p-5">
            <div className="mb-2 flex justify-between text-sm"><span className="font-semibold text-text">Spend today</span><span className="tabular-nums text-text-2">${spent.toFixed(3)} / ${cap.toFixed(2)}</span></div>
            <Progress value={Math.min(100, (spent / cap) * 100)} />
            <p className="mt-2 text-xs text-text-3">Users can use 80% of the cap; the last 20% is reserved for admins.</p>
          </div>
          <Section title="Latest calls">
            {(usage.data ?? []).length === 0 ? <p className="text-sm text-text-2">No AI calls today.</p> : (
              <div className="overflow-x-auto rounded-xl border border-border bg-surface">
                <table className="w-full text-sm">
                  <thead className="text-left text-xs text-text-3"><tr><th className="p-3">Time</th><th className="p-3">Feature</th><th className="p-3">Tokens</th><th className="p-3">Cost</th><th className="p-3">Result</th></tr></thead>
                  <tbody>
                    {(usage.data ?? []).slice(0, 20).map((u) => (
                      <tr key={u.id} className="border-t border-border">
                        <td className="p-3 tabular-nums text-text-2">{new Date(u.created_at).toLocaleTimeString()}</td>
                        <td className="p-3 text-text">{u.feature}</td>
                        <td className="p-3 tabular-nums">{u.tokens}</td>
                        <td className="p-3 tabular-nums">${Number(u.cost_usd).toFixed(4)}</td>
                        <td className="p-3">{u.fallback ? <span className="text-text-3">Fallback · {u.reason}</span> : <span className="text-forest">AI</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Section>
        </TabsContent>

        <TabsContent value="users" className="mt-6 flex flex-col gap-4">
          <Input placeholder="Search by name" value={search} onChange={(e) => setSearch(e.target.value)} maxLength={80} />
          <div className="flex flex-col gap-2">
            {users.map((u) => (
              <div key={u.id} className="flex flex-col gap-2 rounded-xl border border-border bg-surface p-4 sm:flex-row sm:items-center">
                <Link to="/v/$id" params={{ id: u.id }} className="flex-1 font-semibold text-text hover:text-brand">{u.display_name || "Unnamed"}</Link>
                <div className="flex flex-wrap gap-2">
                  {ROLES.map((r) => {
                    const on = u.roles.includes(r);
                    return (
                      <button key={r} onClick={() => setRole(u.id, r, !on)} className={on ? "rounded-full bg-brand px-3 py-1 text-xs font-semibold text-on-brand" : "rounded-full border border-border px-3 py-1 text-xs text-text-2"}>
                        {r.replace("_", " ")}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="audit" className="mt-6 flex flex-col gap-4">
          <div className="flex flex-wrap gap-2">
            {actions.map((a) => (
              <button key={a} onClick={() => setAction(a)} className={a === action ? "rounded-full bg-brand px-3 py-1 text-xs font-semibold text-on-brand" : "rounded-full border border-border px-3 py-1 text-xs text-text-2"}>{a}</button>
            ))}
          </div>
          <div className="flex flex-col divide-y divide-border rounded-xl border border-border bg-surface">
            {(audit.data ?? []).filter((a) => action === "all" || a.action === action).map((a) => (
              <div key={a.id} className="flex items-center justify-between gap-4 p-3 text-sm">
                <span className="font-semibold text-text">{a.action}</span>
                <span className="flex-1 truncate text-xs text-text-3">{JSON.stringify(a.detail)}</span>
                <span className="tabular-nums text-xs text-text-2">{new Date(a.created_at).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </WidePage>
  );
}
